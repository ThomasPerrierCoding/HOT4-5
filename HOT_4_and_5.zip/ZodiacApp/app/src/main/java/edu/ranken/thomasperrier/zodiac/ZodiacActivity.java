package edu.ranken.thomasperrier.zodiac;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.content.Intent;
import android.widget.ImageView;
import android.widget.TextView;


public class ZodiacActivity extends AppCompatActivity {

    Button buttonReturnToMain;
    ImageView imageViewZodiacSign;
    TextView textViewInfo;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_zodiac);

        buttonReturnToMain = (Button) findViewById(R.id.buttonReturn);
        imageViewZodiacSign = findViewById(R.id.imageViewZodiacSign);
        textViewInfo = findViewById(R.id.textViewInfo);

        Intent intent = getIntent();

        String sign = intent.getStringExtra("ZODIACSIGN");

        if(sign.equals("Aries")){
            imageViewZodiacSign.setImageResource(R.drawable.ares);
            textViewInfo.setText("Aries loves to be number one, so it’s no surprise that these audacious rams are the first sign of the zodiac.\nBold and ambitious, Aries dives headfirst into even the most challenging situations.");
        }
        else if(sign.equals("Taurus")){
            imageViewZodiacSign.setImageResource(R.drawable.taurus);
            textViewInfo.setText("Taurus is an earth sign represented by the bull.\nLike their celestial spirit animal, Taureans enjoy relaxing in serene, bucolic environments surrounded by soft sounds, soothing aromas, and succulent flavors.");
        }
        else if(sign.equals("Virgo")){
            imageViewZodiacSign.setImageResource(R.drawable.virgo);
            textViewInfo.setText("Virgo is an earth sign historically represented by the goddess of wheat and agriculture, an association that speaks to Virgo’s deep-rooted presence in the material world.\nVirgos are logical, practical, and systematic in their approach to life. This earth sign is a perfectionist at heart and isn’t afraid to improve skills through diligent and consistent practice.");
        }
        else if(sign.equals("Pisces")){
            imageViewZodiacSign.setImageResource(R.drawable.pisces);
            textViewInfo.setText("Pisces, a water sign, is the last constellation of the zodiac. It's symbolized by two fish swimming in opposite directions, representing the constant division of Pisces' attention between fantasy and reality.\nAs the final sign, Pisces has absorbed every lesson — the joys and the pain, the hopes and the fears — learned by all of the other signs.");
        }
        else if(sign.equals("Capricorn")){
            imageViewZodiacSign.setImageResource(R.drawable.capricorn);
            textViewInfo.setText("The last earth sign of the zodiac, Capricorn is represented by the sea goat, a mythological creature with the body of a goat and tail of a fish.\nAccordingly, Capricorns are skilled at navigating both the material and emotional realms.");
        }
        else if(sign.equals("Scorpio")){
            imageViewZodiacSign.setImageResource(R.drawable.socrpio);
            textViewInfo.setText("Scorpio is one of the most misunderstood signs of the zodiac. Because of its incredible passion and power, Scorpio is often mistaken for a fire sign.\nIn fact, Scorpio is a water sign that derives its strength from the psychic, emotional realm.");
        }
        else if(sign.equals("Leo")){
            imageViewZodiacSign.setImageResource(R.drawable.leo);
            textViewInfo.setText("Roll out the red carpet because Leo has arrived. Leo is represented by the lion and these spirited fire signs are the kings and queens of the celestial jungle.\nThey’re delighted to embrace their royal status: Vivacious, theatrical, and passionate, Leos love to bask in the spotlight and celebrate themselves.");
        }
        else if(sign.equals("Libra")){
            imageViewZodiacSign.setImageResource(R.drawable.libra);
            textViewInfo.setText("Libra is an air sign represented by the scales (interestingly, the only inanimate object of the zodiac), an association that reflects Libra's fixation on balance and harmony.\nLibra is obsessed with symmetry and strives to create equilibrium in all areas of life.");
        }
        else if(sign.equals("Aquarius")){
            imageViewZodiacSign.setImageResource(R.drawable.aquarius);
            textViewInfo.setText("Despite the “aqua” in its name, Aquarius is actually the last air sign of the zodiac.\nAquarius is represented by the water bearer, the mystical healer who bestows water, or life, upon the land. Accordingly, Aquarius is the most humanitarian astrological sign.");
        }
        else if(sign.equals("Sagittarius")){
            imageViewZodiacSign.setImageResource(R.drawable.sagittarius);
            textViewInfo.setText("Represented by the archer, Sagittarians are always on a quest for knowledge.\nThe last fire sign of the zodiac, Sagittarius launches its many pursuits like blazing arrows, chasing after geographical, intellectual, and spiritual adventures.");
        }
        else if(sign.equals("Cancer")){
            imageViewZodiacSign.setImageResource(R.drawable.cancer);
            textViewInfo.setText("Cancer is a cardinal water sign. Represented by the crab, this crustacean seamlessly weaves between the sea and shore representing Cancer’s ability to exist in both emotional and material realms.\nCancers are highly intuitive and their psychic abilities manifest in tangible spaces: For instance, Cancers can effortlessly pick up the energies in a room.");
        }
        else if(sign.equals("Gemini")){
            imageViewZodiacSign.setImageResource(R.drawable.gemini);
            textViewInfo.setText("Have you ever been so busy that you wished you could clone yourself just to get everything done? That’s the Gemini experience in a nutshell.\nAppropriately symbolized by the celestial twins, this air sign was interested in so many pursuits that it had to double itself.");
        }


        buttonReturnToMain.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });
    }
}
