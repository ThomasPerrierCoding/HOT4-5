package edu.ranken.thomasperrier.zodiac;

import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;

public class MainActivity extends AppCompatActivity {


    // Program int Constants
    final int MAXDAY1 = 31;
    final int MAXDAY2 = 30;
    final int MAXDAY3 = 29;
    final int MAXDAY4 = 28;
    final int MAXMONTH = 12;
    final int MINMONTH = 1;
    final int MINDAY = 1;
    final int MAXYEAR = 2020;
    final int MINYEAR = 1890;

    // Program String Constants
    final String OORDAY1 = "Day Inputted Out Of Range\nDay Must Be Between " + MINDAY + " and " + MAXDAY1;
    final String OORDAY2 = "Day Inputted Out Of Range\nDay Must Be Between " + MINDAY + " and " + MAXDAY2;
    final String OORDAY3 = "Day Inputted Out Of Range\nDay Must Be Between " + MINDAY + " and " + MAXDAY3;
    final String OORDAY4 = "Day Inputted Out Of Range\nDay Must Be Between " + MINDAY + " and " + MAXDAY4;
    final String OORYEAR = "Year Inputted Out Of Range\nYear Must Be Between " + MINYEAR + " and " + MAXYEAR;
    final String OORMONTH = "Month Inputted Out Of Range\nMonth Must Be Between " + MINMONTH + " and " + MAXMONTH;
    final String NIP = "NO INPUT PROVIDED";
    final String MONDAY = "Monday";
    final String TUESDAY = "Tuesday";
    final String WEDNESDAY = "Wednesday";
    final String THURSDAY = "Thursday";
    final String FRIDAY = "Friday";
    final String SATURDAY = "Saturday";
    final String SUNDAY = "Sunday";

    final String ARIES = "Aries";
    final String PISCES = "Pisces";
    final String CANCER = "Cancer";
    final String LEO = "Leo";
    final String VIRGO = "Virgo";
    final String LIBRA = "Libra";
    final String CAPRICORN = "Capricorn";
    final String GEMINI = "Gemini";
    final String SCORPIO = "Scorpio";
    final String TAURUS = "Taurus";
    final String SAGITTARIUS = "Sagittarius";
    final String AQUARIUS = "Aquarius";

    // Program Widget Variables
    EditText editTextDay;
    EditText editTextYear;
    EditText editTextMonth;
    Button buttonValidate;
    Button buttonZodiac;
    Button buttonClear;

    // Program Non-Widget Variables
    int month = 0;
    int day = 0;
    int year = 0;
    String age = "";
    String dayOfWeek = "";
    String inputtedDate = "";
    String zodiacSign = "";
    Date userDate;
    boolean keepGoing;
    boolean monthIsValid;
    boolean dayIsValid;
    boolean yearIsValid;
    boolean isLeapYear;
    DateFormat formatter ;
    Date date ;

    @SuppressLint("SimpleDateFormat")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        keepGoing = true;
        monthIsValid = true;
        dayIsValid = true;
        yearIsValid = true;
        isLeapYear = true;

        formatter = new SimpleDateFormat("mm/dd/yyyy");

        editTextDay = findViewById(R.id.editTextDay);
        editTextMonth = findViewById(R.id.editTextMonth);
        editTextYear = findViewById(R.id.editTextYear);
        buttonValidate = findViewById(R.id.buttonValidate);
        buttonZodiac = findViewById(R.id.buttonZodiac);
        buttonClear = findViewById(R.id.buttonClear);

        buttonValidate.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                keepGoing = checkForNoInput();

                if(keepGoing){
                    monthIsValid = validateMonth();
                    if(monthIsValid){
                        yearIsValid = validateYear();
                        if(yearIsValid){
                            isLeapYear = validateLeapYear();
                            dayIsValid = validateDay();
                            if(dayIsValid){
                                dayOfWeek = calculateDayOfWeek();
                                age = calculateAge();
                                zodiacSign = calculateZodiacSign();
                                Toast toast = Toast.makeText(getApplicationContext(), dayOfWeek + age, Toast.LENGTH_LONG);
                                toast.show();
                                buttonZodiac.setEnabled(true);
                            }
                            else if(month == 1 || month == 3 || month == 5 || month == 7 || month == 8 || month == 10 || month == 12){
                                Toast toast = Toast.makeText(getApplicationContext(), OORDAY1, Toast.LENGTH_LONG);
                                toast.show();
                                editTextDay.setText("");
                                editTextDay.requestFocus();
                            }
                            else if(month == 4 || month == 6 || month == 9 || month == 11){
                                Toast toast = Toast.makeText(getApplicationContext(), OORDAY2, Toast.LENGTH_LONG);
                                toast.show();
                                editTextDay.setText("");
                                editTextDay.requestFocus();
                            }
                            else if(month == 2 && isLeapYear){
                                Toast toast = Toast.makeText(getApplicationContext(), OORDAY3, Toast.LENGTH_LONG);
                                toast.show();
                                editTextDay.setText("");
                                editTextDay.requestFocus();
                            }
                            else{
                                Toast toast = Toast.makeText(getApplicationContext(), OORDAY4, Toast.LENGTH_LONG);
                                toast.show();
                                editTextDay.setText("");
                                editTextDay.requestFocus();
                            }
                        }
                        else{
                            Toast toast = Toast.makeText(getApplicationContext(), OORYEAR, Toast.LENGTH_LONG);
                            toast.show();
                            editTextYear.setText("");
                            editTextYear.requestFocus();
                        }
                    }
                    else{
                        Toast toast = Toast.makeText(getApplicationContext(), OORMONTH, Toast.LENGTH_LONG);
                        toast.show();
                        editTextMonth.setText("");
                        editTextMonth.requestFocus();
                    }
                }
            }
        });

        buttonZodiac.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(MainActivity.this,ZodiacActivity.class);
                intent.putExtra("ZODIACSIGN", zodiacSign);

                startActivity(intent);
            }
        });

        buttonClear.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                editTextMonth.setText("");
                editTextDay.setText("");
                editTextYear.setText("");
                editTextMonth.requestFocus();
            }
        });
    }

    private boolean checkForNoInput() {

        if(editTextMonth.getText().toString().isEmpty()){
            Toast toast = Toast.makeText(getApplicationContext(),NIP + "FOR MONTH", Toast.LENGTH_LONG);
            toast.show();
            return false;
        }
        else if(editTextDay.getText().toString().isEmpty()){
            Toast toast = Toast.makeText(getApplicationContext(),NIP + "FOR DAY", Toast.LENGTH_LONG);
            toast.show();
            return false;
        }
        else if(editTextYear.getText().toString().isEmpty()){
            Toast toast = Toast.makeText(getApplicationContext(),NIP + "FOR YEAR", Toast.LENGTH_LONG);
            toast.show();
            return false;
        }
        else{
            return true;
        }
    }

    private boolean validateMonth(){

        if(Integer.valueOf(editTextMonth.getText().toString()) >= MINMONTH && Integer.valueOf(editTextMonth.getText().toString()) <= MAXMONTH){
            month = Integer.valueOf(editTextMonth.getText().toString());
            return true;
        }
        else{
            return false;
        }

    }
    private boolean validateDay(){
        if((month == 1 || month == 3 || month == 5 || month == 7 || month == 8 || month == 10 || month == 12) && Integer.valueOf(editTextDay.getText().toString()) >= MINDAY && Integer.valueOf(editTextDay.getText().toString()) <= MAXDAY1){
            day = Integer.valueOf(editTextDay.getText().toString());
            return true;
        }
        else if((month == 4 || month == 6 || month == 9 || month == 11) && Integer.valueOf(editTextDay.getText().toString()) >= MINDAY && Integer.valueOf(editTextDay.getText().toString()) <= MAXDAY2){
            day = Integer.valueOf(editTextDay.getText().toString());
            return true;
        }
        else if((month == 2 && isLeapYear) && Integer.valueOf(editTextDay.getText().toString()) >= MINDAY && Integer.valueOf(editTextDay.getText().toString()) <= MAXDAY3){
            day = Integer.valueOf(editTextDay.getText().toString());
            return true;
        }
        else if((month == 2) && Integer.valueOf(editTextDay.getText().toString()) >= MINDAY && Integer.valueOf(editTextDay.getText().toString()) <= MAXDAY4){
            day = Integer.valueOf(editTextDay.getText().toString());
            return true;
        }
        else{
            return false;
        }
    }
    private boolean validateYear(){
        if(Integer.valueOf(editTextYear.getText().toString()) >= MINYEAR && Integer.valueOf(editTextYear.getText().toString()) <= MAXYEAR){
            year = Integer.valueOf(editTextYear.getText().toString());
            return true;
        }
        else{
            return false;
        }
    }

    private boolean validateLeapYear(){

        if (year == 1892) {
            return true;
        } else if (year == 1896) {
            return true;
        } else if (year == 1904) {
            return true;
        } else if (year == 1908) {
            return true;
        } else if (year == 1912) {
            return true;
        } else if (year == 1916) {
            return true;
        } else if (year == 1920) {
            return true;
        } else if (year == 1924) {
            return true;
        } else if (year == 1928) {
            return true;
        } else if (year == 1932) {
            return true;
        } else if (year == 1936) {
            return true;
        } else if (year == 1940) {
            return true;
        } else if (year == 1944) {
            return true;
        } else if (year == 1948) {
            return true;
        } else if (year == 1952) {
            return true;
        } else if (year == 1956) {
            return true;
        } else if (year == 1960) {
            return true;
        } else if (year == 1964) {
            return true;
        } else if (year == 1968) {
            return true;
        } else if (year == 1972) {
            return true;
        } else if (year == 1976) {
            return true;
        } else if (year == 1980) {
            return true;
        } else if (year == 1984) {
            return true;
        } else if (year == 1988) {
            return true;
        } else if (year == 1992) {
            return true;
        } else if (year == 1996) {
            return true;
        } else if (year == 2000) {
            return true;
        } else if (year == 2004) {
            return true;
        } else if (year == 2008) {
            return true;
        } else if (year == 2012) {
            return true;
        } else if (year == 2016) {
            return true;
        } else if (year == 2020) {
            return true;
        } else {
            return false;
        }
    }

    private String calculateDayOfWeek(){
        inputtedDate = month+"/"+day+"/"+year;


        try {
            date = (Date)formatter.parse(inputtedDate);
        } catch (ParseException e) {
            e.printStackTrace();
        }
        userDate = date;

        Calendar c = Calendar.getInstance();
        c.setTime(date);
        int dayOfWeek = c.get(Calendar.DAY_OF_WEEK);

        if(dayOfWeek == 1){
            return "You were born on a " + SUNDAY;
        }
        else if(dayOfWeek == 2){
            return "You were born on a " + MONDAY;
        }
        else if(dayOfWeek == 3){
            return "You were born on a " + TUESDAY;
        }
        else if(dayOfWeek == 4){
            return "You were born on a " + WEDNESDAY;
        }
        else if(dayOfWeek == 5){
            return "You were born on a " + THURSDAY;
        }
        else if(dayOfWeek == 6){
            return "You were born on a " + FRIDAY;
        }
        else{
            return "You were born on a " + SATURDAY;
        }
    }

    private String calculateAge(){

        int a;

        a = (MAXYEAR - year);

        return "\nYour age is " + a;
    }

    private String calculateZodiacSign(){

        if((month == 3 && (day >= 21 && day <= 31)) || (month == 4 && (day >= 1 && day <= 20))){
            return ARIES;
        }
        else if((month == 4 && (day >= 21 && day <= 30)) || (month == 5 && (day >= 1 && day <= 20))){
            return TAURUS;
        }
        else if((month == 5 && (day >= 21 && day <= 31)) || (month == 6 && (day >= 1 && day <= 20))){
            return GEMINI;
        }
        else if((month == 6 && (day >= 21 && day <= 30)) || (month == 7 && (day >= 1 && day <= 20))){
            return CANCER;
        }
        else if((month == 7 && (day >= 21 && day <= 31)) || (month == 8 && (day >= 1 && day <= 20))){
            return LEO;
        }
        else if((month == 8 && (day >= 21 && day <= 31)) || (month == 9 && (day >= 1 && day <= 20))){
            return VIRGO;
        }
        else if((month == 9 && (day >= 21 && day <= 30)) || (month == 10 && (day >= 1 && day <= 20))){
            return LIBRA;
        }
        else if((month == 10 && (day >= 21 && day <= 31)) || (month == 11 && (day >= 1 && day <= 20))){
            return SCORPIO;
        }
        else if((month == 11 && (day >= 21 && day <= 30)) || (month == 12 && (day >= 1 && day <= 20))){
            return SAGITTARIUS;
        }
        else if((month == 12 && (day >= 21 && day <= 31)) || (month == 1 && (day >= 1 && day <= 20))){
            return CAPRICORN;
        }
        else if((month == 1 && (day >= 21 && day <= 31)) || (month == 2 && (day >= 1 && day <= 20))){
            return AQUARIUS;
        }
        else{
            return PISCES;
        }
    }
}
